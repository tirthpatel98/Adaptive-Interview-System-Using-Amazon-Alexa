package com.amazon.ask.helloworld.handlers;

import static com.amazon.ask.request.Predicates.intentName;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.helloworld.jdbc.jdbcMethods;
import com.amazon.ask.model.Intent;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Request;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;

public class SubCategoryIntentHandler implements RequestHandler {

	jdbcMethods meth = new jdbcMethods();
	public static final String SUBCATEGORY_KEY = "SubCategoryName";
	public static final String SUBCATEGORY_SLOT = "subcategory";
	
	
	@Override
	public boolean canHandle(HandlerInput input) {
		return input.matches(intentName("subcategoryIntent"));
	}

	@Override
	public Optional<Response> handle(HandlerInput input) {
		Request request = input.getRequestEnvelope().getRequest();
		IntentRequest intentRequest = (IntentRequest)request;
		Intent intent = intentRequest.getIntent();
		Map<String, Slot> slots= intent.getSlots();
		
		Slot subcategorySlot=slots.get(SUBCATEGORY_SLOT);
		
		String speechText, repromptText;
		List ls= new ArrayList();
		List ls1= new ArrayList();
		List categoryIdList = new ArrayList();
		
		String subcategory = subcategorySlot.getValue();
		
		input.getAttributesManager().setSessionAttributes(Collections.singletonMap(SUBCATEGORY_KEY, subcategory));
		
		try {
			ls=meth.searchSubCategoryId(subcategory);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int subcategoryId=(Integer)ls.get(0);
		
		try {
			categoryIdList = meth.searchCategoryFromTemp();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int categoryId=(Integer)categoryIdList.get(0);
		
		
		try {
			meth.insertSubCategoryId(categoryId,subcategoryId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		speechText=String.format("SubCategory you have chosen is %s ,Now you can start test by saying 'Start test", subcategory);
		
		return input.getResponseBuilder()
				.withSimpleCard("Name",speechText)
				.withSpeech(speechText)
				.withReprompt(speechText)
				.withShouldEndSession(false)
				.build();
	}

}
