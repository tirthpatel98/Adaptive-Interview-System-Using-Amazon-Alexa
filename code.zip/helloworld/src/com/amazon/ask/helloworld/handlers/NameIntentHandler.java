package com.amazon.ask.helloworld.handlers;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.helloworld.jdbc.jdbcMethods;
import com.amazon.ask.model.Intent;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Request;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;

import static com.amazon.ask.helloworld.handlers.WhatsMyNameIntentHandler.NAME_KEY;
import static com.amazon.ask.helloworld.handlers.WhatsMyNameIntentHandler.NAME_SLOT;

import static com.amazon.ask.request.Predicates.intentName;
public class NameIntentHandler implements RequestHandler{

jdbcMethods jdbc = new jdbcMethods();	
	
	@Override
	public boolean canHandle(HandlerInput input) {
		return input.matches(intentName("MyNameIntent"));
		
	}

	@Override
	public Optional<Response> handle(HandlerInput input) {
		Request request = input.getRequestEnvelope().getRequest();
		IntentRequest intentRequest = (IntentRequest)request;
		Intent intent = intentRequest.getIntent();
		Map<String, Slot> slots= intent.getSlots();
		
		Slot nameSlot=slots.get(NAME_SLOT);
		String speechText, repromptText;
		
		
		
	//	if(nameSlot!=null && nameSlot.getResolutions()!=null && nameSlot.getResolutions().toString().contains("ER_SUCCESS_MATCH")){
			String myname = nameSlot.getValue();
			//input.getAttributesManager().setSessionAttributes(Collections.singletonMap(NAME_KEY, myname));
			
			
			/*jdbc.insert(myname);*/
			
			speechText= String.format("I now know that your name is %s. You can ask me your "
                    + "name by saying, what's my name?", myname);
			
		//}
		/*else{
            // Render an error since user input is out of list of color defined in interaction model.
            speechText = "Please provide a valid name. " +
                    "Please try again.";
           
        }*/
		
		return input.getResponseBuilder()
				.withSimpleCard("Name",speechText)
				.withSpeech(speechText)
				.withReprompt(speechText)
				.withShouldEndSession(false)
				.build();

	}
}
