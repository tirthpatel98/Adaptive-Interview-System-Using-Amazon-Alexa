package com.amazon.ask.helloworld.handlers;

import static com.amazon.ask.request.Predicates.intentName;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.helloworld.jdbc.jdbcMethods;
import com.amazon.ask.model.Intent;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Request;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;

import static com.amazon.ask.helloworld.handlers.CategoryIntentHandler.CATEGORY_KEY;

public class QuestionIntentHandler implements RequestHandler {

	
	
	public static final String QUESTION_KEY = "questionName";
	jdbcMethods meth= new jdbcMethods();
	
	@Override
	public boolean canHandle(HandlerInput input) {
		
		return input.matches(intentName("questionIntent"));
	}

	@Override
	public Optional<Response> handle(HandlerInput input) {
		
		String speechText, repromptText;
		List questionList= new ArrayList();
		List levelList=new ArrayList();
		List quesScoreList= new ArrayList();
		List quesLevelList=new ArrayList();
		List categoryList= new ArrayList();
		List subcategoryList=new ArrayList();
		List ls1 =new ArrayList();
		List ls2 = new ArrayList();
		
		
		try {
			ResultSet rs1 = meth.searchCatandSubFromTemp();
		
			while(rs1.next()){
				categoryList.add(rs1.getInt("categoryId"));
				subcategoryList.add(rs1.getInt("subcategoryId"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int categoryId=(Integer)categoryList.get(0);
		int subcategoryId=(Integer)subcategoryList.get(0);
		
		System.out.println("cat id"+categoryId+"subcat id "+subcategoryId);
		
		List currentIndexList =new ArrayList();
		try {
			currentIndexList=meth.searchCurrentIndex();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		if(currentIndexList.size()==0){
		try {
			ResultSet rs=meth.searchQuestion(categoryId, subcategoryId,13);
			while(rs.next()){
				questionList.add(rs.getString("question"));
				levelList.add(rs.getInt("examlevel"));
				
			}
	System.out.println("questionList "+questionList.size()+" levelList "+levelList.size());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		else{
			int currentIndex=(Integer)currentIndexList.get(0);
			System.out.println("currentIndex in else "+currentIndex);
			try {
				ResultSet rs=meth.searchquesResult(currentIndex);
				while(rs.next()){
					quesScoreList.add(rs.getDouble("quesScore"));
					quesLevelList.add(rs.getInt("levelId"));
					
					
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			double quesScore = (Double)quesScoreList.get(0);
			int quesLevel = (Integer)quesLevelList.get(0);
			System.out.println(">>>>>>>>>quesScore of previous q "+quesScore);
			System.out.println(">>>>>>>>>quesLevel of previous q "+quesLevel);
			
			if(quesScore<0.4){
				if(quesLevel==13){
					quesLevel=quesLevel;
					System.out.println("level13 print quesLevel"+quesLevel+" "+quesScore);
				}
				else
				{
					quesLevel=quesLevel-1;
					System.out.println("level 14 or 15 print quesLevel"+quesLevel+" "+quesScore);
				}
				
			}
			else if(0.4<=quesScore && quesScore<=0.6){
				quesLevel=quesLevel;
				System.out.println("???????????/score 0.4 to 0.6 print quesLevel"+quesLevel+" "+quesScore);
			}
			else {
				if(quesLevel==15){
					quesLevel=quesLevel;
					System.out.println(">>>>>>>>>>>level15 print11 quesLevel"+quesLevel+" "+quesScore);
				}
				else{
					quesLevel=quesLevel+1;
					System.out.println("<<<<<<<<<<<level15 print quesLevel"+quesLevel+" "+quesScore);
				}
			}
			
			ResultSet rs;
			try {
				System.out.println("cid  subid  quesLevel "+categoryId+subcategoryId+quesLevel);
				rs = meth.searchQuestion(categoryId, subcategoryId,quesLevel);
				while(rs.next()){
					questionList.add(rs.getString("question"));
					levelList.add(rs.getInt("examlevel"));
					
			}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("questionList"+questionList);
			System.out.println("levelList"+levelList);
			
		
		}	
		
		try {
			int j=1;
			
			System.out.println("currentIndexList"+currentIndexList.size());
		
			if(currentIndexList.size()==0){
			meth.insertCurrentIndex(j,(Integer)levelList.get(1));
		}
		else{
			
			int currentIndex=(Integer)currentIndexList.get(0);
			currentIndex+=1;
			meth.updateCurrentIndex(currentIndex,(Integer)levelList.get(currentIndex));
			
		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			currentIndexList=meth.searchCurrentIndex();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int currentIndex=(Integer)currentIndexList.get(0);
		System.out.println("currentIndex "+currentIndex);
	
		speechText=questionList.get(currentIndex).toString();
		
		input.getAttributesManager().setSessionAttributes(Collections.singletonMap(QUESTION_KEY,questionList.get(currentIndex).toString()));
		
		speechText = speechText + "You can give answer by saying that 'my answer is....'";
		/*try {
			meth.truncatetable();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		questionList.clear();
		levelList.clear();
		quesScoreList.clear();
		quesLevelList.clear();
		System.out.println("question intent completed");
	return input.getResponseBuilder()
			.withSimpleCard("Name",speechText)
			.withSpeech(speechText)
			.withReprompt(speechText)
			.withShouldEndSession(false)
			.build();
	}
		
}
