package com.amazon.ask.helloworld.handlers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.helloworld.jdbc.jdbcMethods;
import com.amazon.ask.model.Intent;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Request;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;

import static com.amazon.ask.request.Predicates.intentName;
import static com.amazon.ask.helloworld.handlers.WhatsMyNameIntentHandler.NAME_SLOT;

public class CategoryIntentHandler implements RequestHandler {

jdbcMethods meth = new jdbcMethods();
public static final String CATEGORY_KEY = "CategoryName";
public static final String CATEGORY_SLOT = "category";
	
	@Override
	public boolean canHandle(HandlerInput input) {
		
		return input.matches(intentName("categoryIntent"));
	}

	@Override
	public Optional<Response> handle(HandlerInput input) {
		Request request = input.getRequestEnvelope().getRequest();
		IntentRequest intentRequest = (IntentRequest)request;
		Intent intent = intentRequest.getIntent();
		Map<String, Slot> slots= intent.getSlots();
		
		Slot categorySlot=slots.get(CATEGORY_SLOT);
		
		String speechText, repromptText;
		List ls= new ArrayList();
		List ls1= new ArrayList();
		
		String category = categorySlot.getValue();
		//input.getAttributesManager().setSessionAttributes(Collections.singletonMap(CATEGORY_KEY,category));
		
		
		try {
			ls=meth.searchCategoryId(category);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(">>>"+ls.size());
		
		int categoryId=(Integer)ls.get(0);
		
		
		System.out.println(">>>"+categoryId);
		
		try {
			meth.insertCategoryId(categoryId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			ls1=meth.searchSubCategory(categoryId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		speechText=String.format("Category you have chosen is %s ,Now you can choose subcategory by saying 'my subcategory is ", category);
		
		for(int i=0;i<ls1.size();i++){
			speechText+=ls1.get(i).toString();
			
			if(i < ls1.size()-1){
				speechText+=" or ";
			}
			else
				speechText+="'";
		}
		
		return input.getResponseBuilder()
				.withSimpleCard("Name",speechText)
				.withSpeech(speechText)
				.withReprompt(speechText)
				.withShouldEndSession(false)
				.build();
	}

}
