package com.amazon.ask.helloworld.handlers;

import static com.amazon.ask.request.Predicates.intentName;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
//import static com.amazon.ask.helloworld.handlers.CategoryIntentHandler.CATEGORY_KEY;
import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.helloworld.jdbc.jdbcMethods;
import com.amazon.ask.model.Response;
import static com.amazon.ask.helloworld.handlers.QuestionIntentHandler.QUESTION_KEY;

public class RepeatQuestionHandler implements RequestHandler {

	//public static final String QUESTION_KEY = "questionName";
	jdbcMethods meth= new jdbcMethods();
	
	@Override
	public boolean canHandle(HandlerInput input) {
		// TODO Auto-generated method stub
		return input.matches(intentName("repeatQuestionIntent"));
	}

	@Override
	public Optional<Response> handle(HandlerInput input) {
		// TODO Auto-generated method stub
		//String speechText, repromptText;
		
		String speechText = (String) input.getAttributesManager().getSessionAttributes().get(QUESTION_KEY);
		speechText = speechText + "You can give your answer by saying my answer is....";
		return input.getResponseBuilder()
				.withSimpleCard("Name",speechText)
				.withSpeech(speechText)
				.withReprompt(speechText)
				.withShouldEndSession(false)
				.build();
	}

}
