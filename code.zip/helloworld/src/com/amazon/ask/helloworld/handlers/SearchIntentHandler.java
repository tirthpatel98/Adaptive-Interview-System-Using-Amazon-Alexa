package com.amazon.ask.helloworld.handlers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.helloworld.jdbc.jdbcMethods;
import com.amazon.ask.model.Intent;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Request;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;

import static com.amazon.ask.helloworld.handlers.WhatsMyNameIntentHandler.NAME_SLOT;
import static com.amazon.ask.request.Predicates.intentName;

public class SearchIntentHandler implements RequestHandler {

	jdbcMethods jdbc = new jdbcMethods();
	
	@Override
	public boolean canHandle(HandlerInput input) {
		
		// TODO Auto-generated method stub
		return input.matches(intentName("searchIntent"));
	}

	@Override
	public Optional<Response> handle(HandlerInput input) {
		
		Request request = input.getRequestEnvelope().getRequest();
		IntentRequest intentRequest = (IntentRequest)request;
		Intent intent = intentRequest.getIntent();
		Map<String, Slot> slots= intent.getSlots();
		
		Slot nameSlot=slots.get(NAME_SLOT);
		String speechText;
		List ls= new ArrayList();
		
		String myname = nameSlot.getValue();
		
		try {
			 /*ls= jdbc.search(myname);*/
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(ls.size()==0){
			speechText= String.format("Please enter correct name");
		}
		else
			speechText= String.format("Welcome %s",myname);
			
		
		// TODO Auto-generated method stub
		return input.getResponseBuilder()
				.withSimpleCard("Name",speechText)
				.withSpeech(speechText)
				.withReprompt(speechText)
				.withShouldEndSession(false)
				.build();
	}

}
