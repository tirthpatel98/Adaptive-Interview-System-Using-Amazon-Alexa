package com.amazon.ask.helloworld.handlers;

import static com.amazon.ask.request.Predicates.intentName;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.helloworld.jdbc.jdbcMethods;
import com.amazon.ask.model.Response;

public class FinalScoreIntentHandler implements RequestHandler {
final double easyWeight = 0.7;
final double mediumWeight = 0.8;
final double hardWeight = 1;
jdbcMethods meth= new jdbcMethods();
List easyScoreList= new ArrayList();
List mediumScoreList= new ArrayList();
List hardScoreList= new ArrayList();
	@Override
	public boolean canHandle(HandlerInput input) {
		return input.matches(intentName("finalScoreIntent"));
	}

	@Override
	public Optional<Response> handle(HandlerInput input) {
		String speechText, repromptText;
		Double easy=0.0;
		Double medium=0.0;
		Double hard=0.0;
		
		
		try {
			ResultSet rs1= meth.searchFinalResult(13);
			while(rs1.next()){
				easyScoreList.add(rs1.getDouble("quesScore"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("easyList"+easyScoreList.size());
		for(int i=0;i<easyScoreList.size();i++)
		{
			easy=easy+((double)easyScoreList.get(i));
		}
		System.out.println("easy"+easy);
		
		try {
			ResultSet rs2= meth.searchFinalResult(14);
			while(rs2.next()){
				mediumScoreList.add(rs2.getDouble("quesScore"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("mediumList"+mediumScoreList.size());
		for(int i=0;i<mediumScoreList.size();i++)
		{
			medium=medium+((double)mediumScoreList.get(i));
		}
		System.out.println("medium"+medium);
		try {
			ResultSet rs3= meth.searchFinalResult(15);
			while(rs3.next()){
				hardScoreList.add(rs3.getDouble("quesScore"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("hardList"+hardScoreList.size());
		for(int i=0;i<hardScoreList.size();i++)
		{
			hard=hard+((double)hardScoreList.get(i));
		}
		System.out.println("hard"+hard);
		double finalEasy = easy*easyWeight;
		double finalMedium= medium*mediumWeight;
		double finalHard= hard*hardWeight;
		
		int easyCount=easyScoreList.size();
		int mediumCount=mediumScoreList.size();
		int hardCount=hardScoreList.size();
		
		double total= (easyCount*easyWeight)+(mediumCount*mediumWeight)+(hardCount*hardWeight);
		
		double finalAns= (finalEasy+finalMedium+finalHard)/total;
		finalAns = finalAns * 100;
		int intfinalAns = (int)finalAns;
		System.out.println("final answer "+finalAns);
		speechText = "your result in % is "+finalAns;
		
		try {
			meth.truncateCurrentindex();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			meth.truncateQuesResult();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			meth.truncateAnswer();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//speechText=String.format("Your Result is %s ", finalAns); 
		return input.getResponseBuilder()
				.withSimpleCard("Name",speechText)
				.withSpeech(speechText)
				.withReprompt(speechText)
				.withShouldEndSession(false)
				.build();
		
	}

}
