package com.amazon.ask.helloworld.handlers;

import java.util.Optional;

import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.Response;
import static com.amazon.ask.request.Predicates.intentName;

public class WhatsMyNameIntentHandler implements RequestHandler {
	public static final String NAME_KEY = "NAME";
    public static final String NAME_SLOT = "name";
  
	@Override
	public boolean canHandle(HandlerInput input) {
		return input.matches(intentName("WhatsMyNameIntent"));
	}
	@Override
	public Optional<Response> handle(HandlerInput input) {
		String speechText;
        String name = (String) input.getAttributesManager().getSessionAttributes().get(NAME_KEY);

        boolean noAnswerProvided = false;
        
        speechText = String.format("Your name is %s. Goodbye.", name);
       /* if (name != null && !name.isEmpty()) {
           
        } */
        /*else {
            // Since the user's favorite color is not set render an error message.
            speechText =
                    "I'm not sure what your name is. You can say, my name is "
                            + "abc.";
            noAnswerProvided = true;
        }*/
        
		return input.getResponseBuilder()
                .withSimpleCard("Name", speechText)
                .withSpeech(speechText)
                .withShouldEndSession(!noAnswerProvided)
                .build();

	}

}
