package com.amazon.ask.helloworld.handlers;

import static com.amazon.ask.request.Predicates.intentName;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.helloworld.jdbc.jdbcMethods;
import com.amazon.ask.helloworld.jdbc.nlpmethods;
import com.amazon.ask.model.Intent;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Request;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;
import static com.amazon.ask.helloworld.handlers.QuestionIntentHandler.QUESTION_KEY;

public class AnswerIntentHandler implements RequestHandler {
	
	
	
	List questionIdList= new ArrayList();
	List answerList= new ArrayList();
	List examLevelList= new ArrayList();
	jdbcMethods meth = new jdbcMethods();
	nlpmethods nlp = new nlpmethods();
	public static final String ANSWER_KEY = "AnswerName";
	public static final String ANSWER_SLOT = "answer";
	
	
	
	@Override
	public boolean canHandle(HandlerInput input) {
		return input.matches(intentName("answerIntent"));
	}

	@Override
	public Optional<Response> handle(HandlerInput input) {
		System.out.println("answer intent started");
		String question=(String) input.getAttributesManager().getSessionAttributes().get(QUESTION_KEY);
		System.out.println("question........."+question);
		String speechText, repromptText;
		Request request = input.getRequestEnvelope().getRequest();
		IntentRequest intentRequest = (IntentRequest)request;
		Intent intent = intentRequest.getIntent();
		Map<String, Slot> slots= intent.getSlots();
		
		Slot answerSlot=slots.get(ANSWER_SLOT);	
		
		String answer = answerSlot.getValue();
		System.out.println("answer is obtained"+answer);
		
		try {
			questionIdList = meth.searchQuestionId(question);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		System.out.println("questionIdList<<<<<<<<<<<"+questionIdList.size());
		int questionId=(Integer)questionIdList.get(0);
		System.out.println("questionId<<<<<<<<<<<"+questionId);
		try {
			meth.insertAnswer(answer,questionId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			ResultSet rs1 = meth.searchAnswer(questionId);
		
			while(rs1.next()){
				answerList.add(rs1.getString("answer"));
				examLevelList.add(rs1.getInt("examlevel"));
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("answer list size"+answerList.size());
		System.out.println("examLevel list size"+examLevelList.size());
		
		String answerDb=(String)answerList.get(0);
		answerDb=answerDb.toLowerCase();
		int examlevel=(Integer)examLevelList.get(0);
		
		System.out.println("AnswerDb is "+ answerDb+ " with level"+examlevel);
		
		String tempAnswerDb = nlp.stopwordsremoval(answerDb);
		String tempAnswer = nlp.stopwordsremoval(answer);
		System.out.println("tempansdb "+tempAnswerDb);
		System.out.println("tempAnswer "+tempAnswer);
		 
		String[] answerDbUni=nlp.ngrams(tempAnswerDb, 1);
		String[] answerUni=nlp.ngrams(tempAnswer, 1);
		List<String> answerUniList = Arrays.asList(answerUni); 
		System.out.println("answerUniList  "+answerUniList);
		List<String> answerDbUniList = Arrays.asList(answerDbUni); 
		System.out.println("answerDbUniList  "+answerDbUniList);
		
		String[] answerDbBi=nlp.ngrams(tempAnswerDb, 2);
		String[] answerBi=nlp.ngrams(tempAnswer, 2);
		List<String> answerBiList = Arrays.asList(answerBi); 
		System.out.println("answerBiList  "+answerBiList);
		List answerDbBiList = Arrays.asList(answerDbBi); 
		System.out.println("answerDbBiList  "+answerDbBiList);
		
		String[] answerDbTri=nlp.ngrams(tempAnswerDb, 3);
		String[] answerTri=nlp.ngrams(tempAnswer,3);
		List<String> answerTriList = Arrays.asList(answerTri); 
		System.out.println("answerTriList  "+answerTriList);
		List<String> answerDbTriList = Arrays.asList(answerDbTri); 
		System.out.println("answerDbTriList  "+answerDbTriList);
		
		int uniCount = nlp.compare(answerDbUniList, answerUni);
		final double uniWeight = 0.5;
		System.out.println("Unicount is " + uniCount);
		
		int biCount = nlp.compare(answerDbBiList, answerBi);
		final double biWeight = 0.7;
		System.out.println("Bicount is " + biCount);
		
		int triCount = nlp.compare(answerDbTriList, answerTri);
		final double triWeight = 1;
		System.out.println("Tricount is " + triCount);
		
		double uniScore = uniCount * uniWeight;
		double biScore = biCount * biWeight;
		double triScore = triCount * triWeight;
		
		double total= (answerDbUniList.size()*uniWeight) + (answerDbBiList.size()*biWeight) + (answerDbTriList.size()*triWeight);
		
		double ngramResult= (uniScore+biScore+triScore)/total;
		System.out.println("Result is "+ ngramResult);
		
		try {
			List currentIndexList =new ArrayList();
			currentIndexList=meth.searchCurrentIndex();
			int currentIndex=(Integer)currentIndexList.get(0);
			System.out.println(">>>>>>>"+ngramResult);
			meth.insertQuesScore(questionId, examlevel, ngramResult,currentIndex);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		 speechText = "Your answer has been recorded, You can proceed by saying 'Next Question'";
		
		 //input.getAttributesManager().getSessionAttributes().remove(QUESTION_KEY);
		 
		 answerList.clear();
		 examLevelList.clear();
		 /*answerUniList.clear();
		 answerDbUniList.clear();
		 answerBiList.clear();
		 answerDbBiList.clear();
		 answerTriList.clear();
		 answerDbTriList.clear();*/
		 System.out.println("ansList size and level list size"+answerList.size() + " " +examLevelList.size() );
		 
		 //String question1=(String) input.getAttributesManager().getSessionAttributes().get(QUESTION_KEY);
		 System.out.println("answer intent completed");
		 
		 //System.out.println("question1........."+question1);
		return input.getResponseBuilder()
				.withSimpleCard("Name", speechText)
				.withSpeech(speechText)
				.withReprompt(speechText)
				.withShouldEndSession(false)
				.build();
	}
	
}
