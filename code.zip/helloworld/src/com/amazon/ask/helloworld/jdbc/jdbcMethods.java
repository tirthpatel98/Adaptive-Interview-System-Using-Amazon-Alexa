package com.amazon.ask.helloworld.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class jdbcMethods {

	public List searchCategory() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from category");
		List ls = new ArrayList();
		while(rs.next()){
			ls.add(rs.getString("categoryName"));
		}
		
		return ls;
	}

	public List searchCategoryId(String category) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from category where categoryName='"+category+"'");
		List ls = new ArrayList();
		while(rs.next()){
			ls.add(rs.getInt("categoryId"));
		}
		
		return ls;
	}
	
	public List searchCategoryFromTemp() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from temp");
		List ls = new ArrayList();
		while(rs.next()){
			ls.add(rs.getInt("categoryId"));
		}
		
		return ls;
	}
	
	
	/*public List searchCategoryIdForQue(String subcategory) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from subcategory where subcategoryName='"+subcategory+"'");
		List ls = new ArrayList();
		while(rs.next()){
			ls.add(rs.getInt("categoryName"));
		}
		
		return ls;
	}*/
	
	public ResultSet searchCatandSubFromTemp() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from temp");
		
		return rs;
	}
	

	public void insertCategoryId(int categoryId) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();	
		d.executeUpdate("insert into temp(categoryId) values('"+categoryId+"')");
	}
	

	public List searchSubCategory(int categoryId) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from subcategory where categoryName='"+categoryId+"'");
	
		List ls = new ArrayList();
		while(rs.next()){
			ls.add(rs.getString("subcategoryName"));
		}
		
		return ls;
	}

	public List searchSubCategoryId(String subcategory) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from subcategory where subcategoryName='"+subcategory+"'");
		List ls = new ArrayList();
		while(rs.next()){
			ls.add(rs.getInt("subcategoryId"));
		}
		
		return ls;
	}

	public void insertSubCategoryId(int categoryId,int subcategoryId) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();	
		d.executeUpdate("update temp set subcategoryId='"+subcategoryId+"' where categoryId='"+categoryId+"'");
		
	}
	
	public ResultSet searchQuestion(int category,int subcategory,int examLevel) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from question where categoryName='"+category+"' and subcategoryName='"+subcategory+"' and examlevel='"+examLevel+"'");
		return rs;
	}
	
	public List searchCurrentIndex() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from currentIndex ");
		List ls = new ArrayList();
		while(rs.next()){
			ls.add(rs.getInt("questionNo"));
		}
		
		return ls;
	}

	public List searchCurrentIndexQueLevel() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from currentIndex ");
		List ls = new ArrayList();
		while(rs.next()){
			ls.add(rs.getInt("questionLevel"));
		}
		
		return ls;
	}
	
	public void insertCurrentIndex(int currentquestionNo,int currentLevel) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();	
		d.executeUpdate("insert into currentIndex(questionNo,questionLevel) values('"+currentquestionNo+"','"+currentLevel+"')");
		
	}
	
	public void updateCurrentIndex(int nextquestionNo, int currentLevel) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();	
		d.executeUpdate("update currentIndex set questionNo='"+nextquestionNo+"',questionLevel='"+currentLevel+"' ");
		
	}

	
	public void truncateCurrentindex() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		d.executeUpdate("truncate table currentIndex");
	}
	
	public void truncateQuesResult() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		d.executeUpdate("truncate table quesResult");
	}
	
	public void truncateAnswer() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		d.executeUpdate("truncate table answer");
	}

	public void insertAnswer(String answer, int Question) throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();	
		d.executeUpdate("insert into answer(answer,questionId) values('"+answer+"','"+Question+"')");
		
	}
	
	
	public List searchQuestionId(String question) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from question where question='"+question+"'");
		List ls = new ArrayList();
		while(rs.next()){
			ls.add(rs.getInt("questionId"));
		}
		
		return ls;
	}

	public ResultSet searchAnswer(int questionId) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from question where questionId='"+questionId+"'");
		
		return rs;
	}
	
	public ResultSet searchFinalResult(int levelId) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from quesResult where levelId='"+levelId+"'");
		
		return rs;
	}
	
	public void insertQuesScore(int quesId, int examLevel, double quesScore,int currentIndex) throws Exception {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();	
		d.executeUpdate("insert into quesResult(quesId,quesScore,levelId,currentIndex) values('"+quesId+"','"+quesScore+"','"+examLevel+"','"+currentIndex+"')");
		
	}
	
	public ResultSet searchquesResult(int questionId) throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://myalexadb.cev53pkfcmd7.us-east-1.rds.amazonaws.com/mydb","root","rootroot");
		Statement d=c.createStatement();
		ResultSet rs = d.executeQuery("select * from quesResult where currentIndex='"+questionId+"'");
		
		return rs;
	}
	
}
